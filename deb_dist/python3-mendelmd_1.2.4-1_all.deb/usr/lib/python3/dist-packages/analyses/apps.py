from django.apps import AppConfig


class AnalysesConfig(AppConfig):
    name = 'analyses'
