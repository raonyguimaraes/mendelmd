from django.apps import AppConfig


class UploadConfig(AppConfig):
    name = 'upload'
