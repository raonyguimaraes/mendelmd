"""Django legacy file."""
