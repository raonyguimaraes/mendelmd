from django.apps import AppConfig


class MappsConfig(AppConfig):
    name = 'mapps'
