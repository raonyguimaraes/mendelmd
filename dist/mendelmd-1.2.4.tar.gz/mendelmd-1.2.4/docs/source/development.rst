Development
===========

For development:

pip install -r requirements.txt 